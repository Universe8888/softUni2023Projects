function sumFirstAndLast(arr) {

    let sum = Number(arr[0]) + Number(arr[arr.length - 1]);

    console.log(sum);

}

sumFirstAndLast(["20", "30", "40"]);