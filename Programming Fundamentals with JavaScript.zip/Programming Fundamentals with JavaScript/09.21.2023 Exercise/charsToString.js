function combineAndPrint(char1, char2, char3) {
    
    let combinedString = char1 + char2 + char3;
    
    
    console.log(combinedString);
}

combineAndPrint('a', 'b', 'c');