function printTownInfo(townName, population, area) {
    console.log(`Town ${townName} has population of ${population} and area ${area} square km.`);
}

printTownInfo('Sofia', 1286383, 492);