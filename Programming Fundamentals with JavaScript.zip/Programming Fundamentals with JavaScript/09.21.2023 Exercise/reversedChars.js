function printReversed(char1, char2, char3) {
    console.log(`${char3} ${char2} ${char1}`);
}

printReversed('A', 'B', 'C');