function calculatePower(base, exponent) {
    
    let result = Math.pow(base, exponent);
    
    
    console.log(result);
}

calculatePower(2, 8);