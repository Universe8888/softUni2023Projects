// TODO: Create Contact model and export it

class Contact {
    constructor(name, numeber) {
        this.name = name;
        this.number = numeber;   
    }
}

module.exports = Contact;