function info(firstName, lastName, age) {
    return{
        firstName: firstName,
        lastName: lastName,
        age: age
    };
}

const result = info("Peter", "Pan", "20");
console.log(result);