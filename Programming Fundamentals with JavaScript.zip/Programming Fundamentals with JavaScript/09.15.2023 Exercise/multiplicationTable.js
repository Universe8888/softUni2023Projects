function timesTable(number) {
    for (let i = 1; i <= 10; i++) {
        console.log(`${number} X ${i} = ${number * i}`);
    }
}

timesTable(5);